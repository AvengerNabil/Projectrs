package com.storemanagement.gui;

import com.storemanagement.model.User;
import com.storemanagement.model.Product;
import com.storemanagement.model.Order;
import com.storemanagement.util.FileUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class StoreManagementSystem extends JFrame {
    private List<User> users;
    private List<Product> products;
    private List<Order> orders;
    private User currentUser;

    public StoreManagementSystem() {
        users = FileUtil.loadUsers();
        products = FileUtil.loadProducts();
        orders = FileUtil.loadOrders();
        addSampleUsers(); // Add sample users
        addSampleProducts(); // Add sample products
        showLoginScreen();
    }

    // Add sample users
    private void addSampleUsers() {
        users.add(new User("admin", "admin@store.com", "admin123", true)); // Admin user
        users.add(new User("john", "john@example.com", "john123", false)); // Customer user
        users.add(new User("alice", "alice@example.com", "alice123", false)); // Customer user
        users.add(new User("bob", "bob@example.com", "bob123", false)); // Customer user
        FileUtil.saveUsers(users); // Save users to file
    }

    // Add sample products
    private void addSampleProducts() {
        products.add(new Product("ASUS VivoBook 15", 55000, 10));
        products.add(new Product("ASUS ROG Zephyrus G14", 95000, 5));
        products.add(new Product("ASUS TUF Gaming A15", 85000, 7));
        products.add(new Product("ASUS ZenBook 13", 75000, 8));
        products.add(new Product("ASUS Chromebook Flip", 65000, 12));

        products.add(new Product("Dell Inspiron 15", 65000, 10));
        products.add(new Product("Dell XPS 13", 105000, 5));
        products.add(new Product("Dell G5 Gaming Laptop", 95000, 6));
        products.add(new Product("Dell Latitude 14", 85000, 8));
        products.add(new Product("Dell Alienware m15", 110000, 4));

        products.add(new Product("Lenovo IdeaPad 3", 50000, 15));
        products.add(new Product("Lenovo ThinkPad X1 Carbon", 90000, 6));
        products.add(new Product("Lenovo Legion 5", 80000, 7));
        products.add(new Product("Lenovo Yoga 9i", 75000, 8));
        products.add(new Product("Lenovo Flex 5", 60000, 10));

        products.add(new Product("iPhone 13", 120000, 5));
        products.add(new Product("iPhone 12", 95000, 8));
        products.add(new Product("iPhone SE (2022)", 90000, 10));
        products.add(new Product("iPhone 11", 85000, 12));
        products.add(new Product("iPhone XR", 75000, 15));

        products.add(new Product("Samsung Galaxy S22", 110000, 6));
        products.add(new Product("Samsung Galaxy S21 FE", 90000, 8));
        products.add(new Product("Samsung Galaxy A73", 70000, 10));
        products.add(new Product("Samsung Galaxy Z Flip 3", 100000, 5));
        products.add(new Product("Samsung Galaxy Note 20", 95000, 7));

        products.add(new Product("Vivo V25 Pro", 50000, 12));
        products.add(new Product("Vivo X80", 70000, 8));
        products.add(new Product("Vivo Y75", 40000, 15));
        products.add(new Product("Vivo T1 44W", 35000, 20));
        products.add(new Product("Vivo Y21", 30000, 25));

        products.add(new Product("iPad Pro 12.9-inch", 130000, 4));
        products.add(new Product("iPad Air (5th Gen)", 110000, 6));
        products.add(new Product("iPad Mini (6th Gen)", 100000, 8));
        products.add(new Product("iPad (9th Gen)", 90000, 10));
        products.add(new Product("iPad (10th Gen)", 85000, 12));

        products.add(new Product("Samsung Galaxy Tab S8 Ultra", 120000, 5));
        products.add(new Product("Samsung Galaxy Tab S7 FE", 90000, 8));
        products.add(new Product("Samsung Galaxy Tab A8", 75000, 10));
        products.add(new Product("Samsung Galaxy Tab S6 Lite", 80000, 12));
        products.add(new Product("Samsung Galaxy Tab Active 3", 85000, 7));

        products.add(new Product("Dell Latitude 7320 Detachable", 125000, 4));
        products.add(new Product("Dell Venue 11 Pro", 95000, 6));
        products.add(new Product("Dell XPS 13 2-in-1", 110000, 5));
        products.add(new Product("Dell Inspiron 14 2-in-1", 100000, 7));
        products.add(new Product("Dell Chromebook 11 2-in-1", 90000, 10));

        FileUtil.saveProducts(products); // Save products to file
    }

    // Show login screen
    private void showLoginScreen() {
        JPanel panel = new JPanel(new GridLayout(3, 2));
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(registerButton);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            User user = authenticate(username, password);
            if (user != null) {
                currentUser = user;
                if (user.isAdmin()) {
                    showAdminHome();
                } else {
                    showCustomerHome();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password");
            }
        });

        registerButton.addActionListener(e -> showRegistrationScreen());

        this.setContentPane(panel);
        this.setSize(300, 150);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    // Authenticate user
    private User authenticate(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    // Show registration screen
    private void showRegistrationScreen() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField usernameField = new JTextField();
        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton registerButton = new JButton("Register");

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel(""));
        panel.add(registerButton);

        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            users.add(new User(username, email, password, false));
            FileUtil.saveUsers(users);
            JOptionPane.showMessageDialog(this, "Registration successful!");
            showLoginScreen();
        });

        this.setContentPane(panel);
        this.setSize(300, 200);
    }

    // Show admin home screen
    private void showAdminHome() {
        JPanel panel = new JPanel(new GridLayout(4, 1));
        JButton productsButton = new JButton("Manage Products");
        JButton ordersButton = new JButton("Manage Orders");
        JButton customersButton = new JButton("Manage Customers");
        JButton logoutButton = new JButton("Logout");

        panel.add(productsButton);
        panel.add(ordersButton);
        panel.add(customersButton);
        panel.add(logoutButton);

        productsButton.addActionListener(e -> showAdminProducts());
        ordersButton.addActionListener(e -> showAdminOrders());
        customersButton.addActionListener(e -> showAdminCustomers());
        logoutButton.addActionListener(e -> showLoginScreen());

        this.setContentPane(panel);
        this.setSize(300, 200);
    }

    // Show admin products screen
    private void showAdminProducts() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea productsArea = new JTextArea();
        JButton addProductButton = new JButton("Add Product");
        JButton searchProductButton = new JButton("Search Product");
        JButton backButton = new JButton("Back");

        for (Product product : products) {
            productsArea.append(product.toString() + "\n");
        }

        panel.add(new JScrollPane(productsArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addProductButton);
        buttonPanel.add(searchProductButton);
        buttonPanel.add(backButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        addProductButton.addActionListener(e -> showAddProductScreen());
        searchProductButton.addActionListener(e -> showSearchProductScreen());
        backButton.addActionListener(e -> showAdminHome());

        this.setContentPane(panel);
        this.setSize(400, 300);
    }

    // Show add product screen
    private void showAddProductScreen() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField nameField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField quantityField = new JTextField();
        JButton addButton = new JButton("Add");

        panel.add(new JLabel("Product Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Price:"));
        panel.add(priceField);
        panel.add(new JLabel("Quantity:"));
        panel.add(quantityField);
        panel.add(new JLabel(""));
        panel.add(addButton);

        addButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());
                int quantity = Integer.parseInt(quantityField.getText());
                products.add(new Product(name, price, quantity));
                FileUtil.saveProducts(products);
                JOptionPane.showMessageDialog(this, "Product added successfully!");
                showAdminProducts();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input!");
            }
        });

        this.setContentPane(panel);
        this.setSize(300, 200);
    }

    // Show search product screen
    private void showSearchProductScreen() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextField searchField = new JTextField();
        JButton searchButton = new JButton("Search");
        JTextArea resultArea = new JTextArea();

        panel.add(searchField, BorderLayout.NORTH);
        panel.add(searchButton, BorderLayout.CENTER);
        panel.add(new JScrollPane(resultArea), BorderLayout.SOUTH);

        searchButton.addActionListener(e -> {
            String query = searchField.getText().toLowerCase();
            resultArea.setText("");
            for (Product product : products) {
                if (product.getName().toLowerCase().contains(query)) {
                    resultArea.append(product.toString() + "\n");
                }
            }
        });

        this.setContentPane(panel);
        this.setSize(400, 300);
    }

    // Show admin orders screen
    private void showAdminOrders() {
        showAllOrders();
    }

    // Show all orders
    private void showAllOrders() {
        StringBuilder allOrders = new StringBuilder();
        allOrders.append("=== All Orders ===\n");
        for (Order order : orders) {
            allOrders.append(order.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(this, allOrders.toString());
    }

    // Show admin customers screen
    private void showAdminCustomers() {
        StringBuilder allCustomers = new StringBuilder();
        allCustomers.append("=== All Customers ===\n");
        for (User user : users) {
            if (!user.isAdmin()) {
                allCustomers.append("Username: ").append(user.getUsername()).append(", Email: ").append(user.getEmail()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(this, allCustomers.toString());
    }

    // Show customer home screen
    private void showCustomerHome() {
        JPanel panel = new JPanel(new GridLayout(3, 1));
        JButton productsButton = new JButton("View Products");
        JButton ordersButton = new JButton("View Orders");
        JButton logoutButton = new JButton("Logout");

        panel.add(productsButton);
        panel.add(ordersButton);
        panel.add(logoutButton);

        productsButton.addActionListener(e -> showCustomerProducts());
        ordersButton.addActionListener(e -> showCustomerOrders());
        logoutButton.addActionListener(e -> showLoginScreen());

        this.setContentPane(panel);
        this.setSize(300, 200);
    }


    // Show customer products screen
    private void showCustomerProducts() {
        JPanel panel = new JPanel(new BorderLayout());
        JTable table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        JButton backButton = new JButton("Back");

        // Create a table model with serial number, product name, and price columns
        String[] columnNames = {"S.No", "Product Name", "Price"};
        Object[][] data = new Object[products.size()][3];

        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            data[i][0] = i + 1; // Serial number
            data[i][1] = product.getName(); // Product name
            data[i][2] = product.getPrice(); // Price
        }

        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make the table non-editable
            }
        };

        table.setModel(model);

        // Add a mouse listener to handle row clicks
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = table.rowAtPoint(evt.getPoint());
                int col = table.columnAtPoint(evt.getPoint());
                if (row >= 0 && col >= 0) {
                    Product selectedProduct = products.get(row);
                    int option = JOptionPane.showConfirmDialog(panel, "Add " + selectedProduct.getName() + " to order?", "Add Product", JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                        List<Product> selectedProducts = new ArrayList<>();
                        selectedProducts.add(selectedProduct);
                        Order order = new Order(currentUser.getUsername(), selectedProducts);
                        orders.add(order);
                        FileUtil.saveOrders(orders);
                        JOptionPane.showMessageDialog(panel, "Product added to order successfully!");
                    }
                }
            }
        });

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);

        backButton.addActionListener(e -> showCustomerHome());

        this.setContentPane(panel);
        this.setSize(500, 300);
    }
    // Show customer orders screen
    private void showCustomerOrders() {
        showPurchaseHistory(currentUser.getUsername());
    }

    // Show purchase history for a specific user
    private void showPurchaseHistory(String username) {
        StringBuilder history = new StringBuilder();
        history.append("=== Purchase History for ").append(username).append(" ===\n");
        for (Order order : orders) {
            if (order.getUsername().equals(username)) {
                history.append(order.toString()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(this, history.toString());
    }

   

    // Show bill for an order
    private void showBill(Order order) {
        StringBuilder bill = new StringBuilder();
        bill.append("=== Bill ===\n");
        bill.append("Order ID: ").append(order.getOrderId()).append("\n");
        bill.append("Customer: ").append(order.getUsername()).append("\n");
        bill.append("Order Date: ").append(order.getOrderDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))).append("\n");
        bill.append("Products:\n");
        for (Product product : order.getProducts()) {
            bill.append("- ").append(product.getName()).append(": $").append(product.getPrice()).append("\n");
        }
        bill.append("Total Amount: $").append(order.getTotalAmount()).append("\n");
        JOptionPane.showMessageDialog(this, bill.toString());
    }

    public static void main(String[] args) {
        new StoreManagementSystem();
    }
}