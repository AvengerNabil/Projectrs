package com.storemanagement.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

public class Order implements Serializable {
    private static int nextOrderId = 1;
    private int orderId;
    private String username;
    private List<Product> products;
    private double totalAmount;
    private LocalDate orderDate;

    public Order(String username, List<Product> products) {
        this.orderId = nextOrderId++;
        this.username = Objects.requireNonNull(username, "Username cannot be null");
        this.products = Objects.requireNonNull(products, "Product list cannot be null");
        this.totalAmount = calculateTotalAmount();
        this.orderDate = LocalDate.now();
    }

    private double calculateTotalAmount() {
        return products.stream().mapToDouble(p -> p.getPrice() * p.getQuantity()).sum();
    }

    public int getOrderId() {
        return orderId;
    }

    public String getUsername() {
        return username;
    }

    public List<Product> getProducts() {
        return products;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        StringBuilder orderDetails = new StringBuilder();
        orderDetails.append("Order ID: ").append(orderId).append("\n");
        orderDetails.append("Customer: ").append(username).append("\n");
        orderDetails.append("Order Date: ").append(orderDate.format(formatter)).append("\n");
        orderDetails.append("Products:\n");

        for (Product product : products) {
            orderDetails.append("- ").append(product.getName())
                    .append(" (x").append(product.getQuantity()).append("): $")
                    .append(product.getPrice() * product.getQuantity()).append("\n");
        }

        orderDetails.append("Total Amount: $").append(totalAmount).append("\n");
        return orderDetails.toString();
    }
}
