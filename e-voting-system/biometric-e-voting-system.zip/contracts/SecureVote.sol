// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title SecureVote
 * @dev A decentralized voting contract with voter authorization and one-vote-per-wallet logic.
 */
contract SecureVote is Ownable, ReentrancyGuard {
    struct Candidate {
        uint id;
        string name;
        string party;
        uint voteCount;
        bool isVerified;
    }

    mapping(uint => Candidate) public candidates;
    mapping(address => bool) public hasVoted;
    mapping(address => bool) public isAuthorized;
    
    uint public candidatesCount;
    uint public totalVotes;

    event VoterAuthorized(address indexed voter);
    event VoteCast(address indexed voter, uint indexed candidateId);
    event CandidateAdded(uint indexed candidateId, string name);
    event CandidateVerified(uint indexed candidateId);

    constructor() Ownable(msg.sender) {
        // Initial candidates for demonstration
        addCandidate("Alice Johnson", "Tech Party");
        addCandidate("Bob Smith", "Green Alliance");
        addCandidate("Charlie Brown", "Innovation Guild");
        
        // Auto-verify initial candidates for convenience
        verifyCandidate(1);
        verifyCandidate(2);
        verifyCandidate(3);
    }

    /**
     * @dev Allows the admin to authorize a voter.
     * @param _voter The address of the voter to authorize.
     */
    function authorizeVoter(address _voter) public onlyOwner {
        require(!isAuthorized[_voter], "Voter already authorized");
        isAuthorized[_voter] = true;
        emit VoterAuthorized(_voter);
    }

    /**
     * @dev Adds a new candidate to the election.
     * @param _name Name of the candidate.
     * @param _party Party affiliation.
     */
    function addCandidate(string memory _name, string memory _party) public onlyOwner {
        candidatesCount++;
        candidates[candidatesCount] = Candidate(candidatesCount, _name, _party, 0, false);
        emit CandidateAdded(candidatesCount, _name);
    }

    /**
     * @dev Verifies a candidate's identity.
     * @param _candidateId The ID of the candidate to verify.
     */
    function verifyCandidate(uint _candidateId) public onlyOwner {
        require(_candidateId > 0 && _candidateId <= candidatesCount, "Invalid candidate ID");
        require(!candidates[_candidateId].isVerified, "Candidate already verified");
        
        candidates[_candidateId].isVerified = true;
        emit CandidateVerified(_candidateId);
    }

    /**
     * @dev Casts a vote for a candidate.
     * @param _candidateId The ID of the candidate to vote for.
     */
    function castVote(uint _candidateId) public nonReentrant {
        require(isAuthorized[msg.sender], "You are not authorized to vote");
        require(!hasVoted[msg.sender], "You have already voted");
        require(_candidateId > 0 && _candidateId <= candidatesCount, "Invalid candidate ID");

        hasVoted[msg.sender] = true;
        candidates[_candidateId].voteCount++;
        totalVotes++;

        emit VoteCast(msg.sender, _candidateId);
    }

    /**
     * @dev Returns candidate details.
     */
    function getCandidate(uint _candidateId) public view returns (Candidate memory) {
        return candidates[_candidateId];
    }
}
