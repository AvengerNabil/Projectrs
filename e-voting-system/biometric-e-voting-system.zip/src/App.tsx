import { useState, useEffect, FormEvent, ChangeEvent } from 'react';
import { ethers } from 'ethers';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Fingerprint, 
  Wallet, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  Vote as VoteIcon,
  ShieldCheck,
  Loader2,
  Camera,
  IdCard,
  UserCheck
} from 'lucide-react';
import { useBiometricAuth } from './hooks/useBiometricAuth';
import { getContract, CONTRACT_ADDRESS } from './lib/blockchain';

interface Candidate {
  id: number;
  name: string;
  party: string;
  voteCount: number;
  isVerified: boolean;
}

export default function App() {
  const [account, setAccount] = useState<string | null>(null);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error' | 'info', message: string } | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [isInIframe, setIsInIframe] = useState(false);
  const [useSimulatedBiometrics, setUseSimulatedBiometrics] = useState(true);
  const [currentView, setCurrentView] = useState<'voting' | 'results'>('voting');
  const [isElectionConcluded, setIsElectionConcluded] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [electionEndTime, setElectionEndTime] = useState<Date | null>(null);
  const [timeLeft, setTimeLeft] = useState<{ hours: number, minutes: number, seconds: number } | null>(null);
  const [newCandidateName, setNewCandidateName] = useState("");
  const [newCandidateParty, setNewCandidateParty] = useState("");
  const [showAddCandidateForm, setShowAddCandidateForm] = useState(false);
  const [electionDuration, setElectionDuration] = useState("2"); // Default 2 hours
  
  // Identity Verification State
  const [isVerifyingIdentity, setIsVerifyingIdentity] = useState(false);
  const [isIdentityVerified, setIsIdentityVerified] = useState(false);
  const [faceImage, setFaceImage] = useState<string | null>(null);
  const [voterIdImage, setVoterIdImage] = useState<string | null>(null);
  const [verificationStep, setVerificationStep] = useState<'face' | 'id' | 'processing'>('face');
  const [pendingCandidateId, setPendingCandidateId] = useState<number | null>(null);

  const { authenticate, isAuthenticating, error: biometricError } = useBiometricAuth();

  const [isDemoMode, setIsDemoMode] = useState(false);

  useEffect(() => {
    const inIframe = window.self !== window.top;
    setIsInIframe(inIframe);
    // Default to simulation if in iframe to prevent errors
    setUseSimulatedBiometrics(inIframe);
  }, []);

  // Countdown timer logic
  useEffect(() => {
    if (!electionEndTime || isElectionConcluded) return;

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = electionEndTime.getTime() - now;

      if (distance < 0) {
        clearInterval(timer);
        setIsElectionConcluded(true);
        setTimeLeft(null);
        return;
      }

      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      setTimeLeft({ hours, minutes, seconds });
    }, 1000);

    return () => clearInterval(timer);
  }, [electionEndTime, isElectionConcluded]);

  // Real-time polling for blockchain data
  useEffect(() => {
    if (isDemoMode || !account || CONTRACT_ADDRESS === "0x0000000000000000000000000000000000000000") return;

    const pollInterval = setInterval(async () => {
      try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        await fetchCandidates(provider);
        setLastUpdated(new Date());
      } catch (err) {
        console.error("Polling failed", err);
      }
    }, 10000); // Poll every 10 seconds

    return () => clearInterval(pollInterval);
  }, [isDemoMode, account]);

  const openInNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  // Connect Wallet
  const connectWallet = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        setLoading(true);
        const provider = new ethers.BrowserProvider(window.ethereum);
        const accounts = await provider.send("eth_requestAccounts", []);
        setAccount(accounts[0]);
        setIsDemoMode(false);

        if (CONTRACT_ADDRESS === "0x0000000000000000000000000000000000000000") {
          setStatus({ 
            type: 'error', 
            message: "Smart contract not deployed. Please update CONTRACT_ADDRESS in blockchain.ts or use Demo Mode." 
          });
          setLoading(false);
          return;
        }

        await checkVoterStatus(accounts[0], provider);
        await fetchCandidates(provider);
      } catch (err: any) {
        setStatus({ type: 'error', message: "Failed to connect wallet: " + err.message });
      } finally {
        setLoading(false);
      }
    } else {
      setStatus({ 
        type: 'error', 
        message: "MetaMask not detected. You can install it at metamask.io or try the Demo Mode below." 
      });
    }
  };

  const startDemoMode = () => {
    setIsDemoMode(true);
    setAccount("0xDemoVoter...1234");
    setIsAuthorized(true);
    setHasVoted(false);
    setIsOwner(true); // Allow testing admin features in demo mode
    
    // Set demo election end time to 2 hours from now
    const endTime = new Date();
    endTime.setHours(endTime.getHours() + 2);
    setElectionEndTime(endTime);

    setCandidates([
      { id: 1, name: "Alice Johnson (Demo)", party: "Tech Party", voteCount: 12, isVerified: true },
      { id: 2, name: "Bob Smith (Demo)", party: "Green Alliance", voteCount: 8, isVerified: true },
      { id: 3, name: "Charlie Brown (Demo)", party: "Innovation Guild", voteCount: 15, isVerified: true },
    ]);
    setStatus({ type: 'success', message: "Demo Mode activated! You are now an admin and can test all features." });
  };

  const checkVoterStatus = async (address: string, provider: ethers.Provider) => {
    if (isDemoMode || CONTRACT_ADDRESS === "0x0000000000000000000000000000000000000000") return;
    try {
      const contract = await getContract(provider);
      const authorized = await contract.isAuthorized(address);
      const voted = await contract.hasVoted(address);
      
      // Check if current user is owner
      try {
        const ownerAddress = await contract.owner();
        setIsOwner(ownerAddress.toLowerCase() === address.toLowerCase());
      } catch (e) {
        console.log("Owner check not available or failed");
      }

      setIsAuthorized(authorized);
      setHasVoted(voted);
    } catch (err: any) {
      console.error("Status check failed", err);
      if (err.code === 'BAD_DATA' || (err.message && err.message.includes('could not decode'))) {
        setStatus({ type: 'error', message: "Contract not found at the specified address. Please check your deployment or use Demo Mode." });
      }
    }
  };

  const handleAuthorize = async () => {
    if (!account) return;

    if (isDemoMode) {
      setLoading(true);
      setTimeout(() => {
        setIsAuthorized(true);
        setStatus({ type: 'success', message: "Account authorized in Demo Mode!" });
        setLoading(false);
      }, 1000);
      return;
    }

    try {
      setLoading(true);
      setStatus({ type: 'info', message: "Requesting authorization on-chain..." });
      
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = await getContract(signer);

      const tx = await contract.authorizeVoter(account);
      await tx.wait();

      setIsAuthorized(true);
      setStatus({ type: 'success', message: "Your account is now authorized to vote!" });
    } catch (err: any) {
      console.error(err);
      setStatus({ 
        type: 'error', 
        message: "Authorization failed. Only the contract owner can authorize voters. (Try Demo Mode to bypass this)" 
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCandidates = async (provider: ethers.Provider) => {
    if (isDemoMode || CONTRACT_ADDRESS === "0x0000000000000000000000000000000000000000") return;
    try {
      const contract = await getContract(provider);
      const count = await contract.candidatesCount();
      const fetchedCandidates: Candidate[] = [];
      for (let i = 1; i <= Number(count); i++) {
        const c = await contract.candidates(i);
        fetchedCandidates.push({
          id: Number(c.id),
          name: c.name,
          party: c.party,
          voteCount: Number(c.voteCount),
          isVerified: c.isVerified
        });
      }
      setCandidates(fetchedCandidates);
    } catch (err: any) {
      console.error("Fetch candidates failed", err);
      if (err.code === 'BAD_DATA' || (err.message && err.message.includes('could not decode'))) {
        setStatus({ type: 'error', message: "Contract not found at the specified address. Please check your deployment or use Demo Mode." });
      }
    }
  };

  const handleVote = async (candidateId: number) => {
    if (!account) return;

    // 0. Identity Verification Gate (Face + Voter ID)
    if (!isIdentityVerified) {
      setPendingCandidateId(candidateId);
      setIsVerifyingIdentity(true);
      return;
    }

    // 1. Biometric Authentication Gate
    setStatus({ type: 'info', message: useSimulatedBiometrics ? "Simulating biometric verification..." : "Please verify your identity using biometrics..." });
    const isVerified = await authenticate(account, useSimulatedBiometrics);
    
    if (!isVerified) {
      setStatus({ type: 'error', message: biometricError || "Biometric verification failed." });
      return;
    }

    // 2. Transaction Logic
    if (isDemoMode) {
      setLoading(true);
      setTimeout(() => {
        setCandidates(prev => prev.map(c => 
          c.id === candidateId ? { ...c, voteCount: c.voteCount + 1 } : c
        ));
        setHasVoted(true);
        setStatus({ type: 'success', message: "Demo Vote cast successfully! (Simulated on-chain)" });
        setLoading(false);
      }, 1500);
      return;
    }

    try {
      setLoading(true);
      setStatus({ type: 'info', message: "Biometrics verified. Sending vote to Polygon..." });
      
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = await getContract(signer);

      const tx = await contract.castVote(candidateId);
      await tx.wait();

      setHasVoted(true);
      setStatus({ type: 'success', message: "Vote cast successfully! Your voice has been heard on-chain." });
      await fetchCandidates(provider);
    } catch (err: any) {
      console.error(err);
      setStatus({ type: 'error', message: err.reason || err.message || "Transaction failed." });
    } finally {
      setLoading(false);
    }
  };

  const handleAddCandidate = async (e: FormEvent) => {
    e.preventDefault();
    if (!newCandidateName || !newCandidateParty) return;

    if (isDemoMode) {
      setLoading(true);
      setTimeout(() => {
        const newId = candidates.length + 1;
        setCandidates(prev => [...prev, {
          id: newId,
          name: newCandidateName,
          party: newCandidateParty,
          voteCount: 0,
          isVerified: false
        }]);
        setNewCandidateName("");
        setNewCandidateParty("");
        setShowAddCandidateForm(false);
        setStatus({ type: 'success', message: "New candidate added successfully in Demo Mode!" });
        setLoading(false);
      }, 1000);
      return;
    }

    try {
      setLoading(true);
      setStatus({ type: 'info', message: "Adding candidate to the blockchain..." });
      
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = await getContract(signer);

      const tx = await contract.addCandidate(newCandidateName, newCandidateParty);
      await tx.wait();

      setNewCandidateName("");
      setNewCandidateParty("");
      setShowAddCandidateForm(false);
      setStatus({ type: 'success', message: "Candidate added successfully to the blockchain!" });
      await fetchCandidates(provider);
    } catch (err: any) {
      console.error(err);
      setStatus({ type: 'error', message: err.reason || err.message || "Failed to add candidate." });
    } finally {
      setLoading(false);
    }
  };

  const handleSetDuration = () => {
    const endTime = new Date();
    endTime.setHours(endTime.getHours() + parseInt(electionDuration));
    setElectionEndTime(endTime);
    setIsElectionConcluded(false);
    setStatus({ type: 'success', message: `Election duration set to ${electionDuration} hours!` });
  };

  const handleVerifyCandidate = async (candidateId: number) => {
    if (!account) return;

    if (isDemoMode) {
      setLoading(true);
      setTimeout(() => {
        setCandidates(prev => prev.map(c => 
          c.id === candidateId ? { ...c, isVerified: true } : c
        ));
        setStatus({ type: 'success', message: "Candidate identity verified in Demo Mode!" });
        setLoading(false);
      }, 1000);
      return;
    }

    try {
      setLoading(true);
      setStatus({ type: 'info', message: "Verifying candidate identity on-chain..." });
      
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = await getContract(signer);

      const tx = await contract.verifyCandidate(candidateId);
      await tx.wait();

      setStatus({ type: 'success', message: "Candidate identity verified successfully!" });
      await fetchCandidates(provider);
    } catch (err: any) {
      console.error(err);
      setStatus({ type: 'error', message: err.reason || err.message || "Verification failed." });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyIdentity = async () => {
    if (!faceImage || !voterIdImage) return;
    
    setVerificationStep('processing');
    setLoading(true);
    
    // Simulate AI verification
    setTimeout(() => {
      setIsIdentityVerified(true);
      setIsVerifyingIdentity(false);
      setLoading(false);
      setStatus({ type: 'success', message: "Identity verified! Face and Voter ID match. You can now proceed to vote." });
      
      // If there was a pending vote, trigger it
      if (pendingCandidateId !== null) {
        handleVote(pendingCandidateId);
        setPendingCandidateId(null);
      }
    }, 3000);
  };

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>, type: 'face' | 'id') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'face') {
          setFaceImage(reader.result as string);
          setVerificationStep('id');
        } else {
          setVoterIdImage(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const totalVotesCast = candidates.reduce((sum, c) => sum + c.voteCount, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Identity Verification Modal */}
      <AnimatePresence>
        {isVerifyingIdentity && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-slate-800">Identity Verification</h3>
                  <button 
                    onClick={() => setIsVerifyingIdentity(false)}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <AlertCircle className="w-6 h-6" />
                  </button>
                </div>

                {verificationStep === 'face' && (
                  <div className="text-center">
                    <div className="bg-indigo-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Camera className="text-indigo-600 w-10 h-10" />
                    </div>
                    <h4 className="text-lg font-bold mb-2">Step 1: Face Verification</h4>
                    <p className="text-slate-500 text-sm mb-8">Please take a clear photo of your face or upload one to verify your identity.</p>
                    
                    <label className="block w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold cursor-pointer transition-all shadow-lg shadow-indigo-100">
                      Take/Upload Photo
                      <input 
                        type="file" 
                        accept="image/*" 
                        capture="user" 
                        className="hidden" 
                        onChange={(e) => handleImageUpload(e, 'face')}
                      />
                    </label>
                  </div>
                )}

                {verificationStep === 'id' && (
                  <div className="text-center">
                    <div className="bg-indigo-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                      <IdCard className="text-indigo-600 w-10 h-10" />
                    </div>
                    <h4 className="text-lg font-bold mb-2">Step 2: Voter ID Verification</h4>
                    <p className="text-slate-500 text-sm mb-8">Please upload a clear photo of your official Voter ID card.</p>
                    
                    <div className="space-y-4">
                      <label className="block w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold cursor-pointer transition-all shadow-lg shadow-indigo-100">
                        Upload ID Card
                        <input 
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          onChange={(e) => handleImageUpload(e, 'id')}
                        />
                      </label>
                      
                      {voterIdImage && (
                        <button
                          onClick={handleVerifyIdentity}
                          className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-bold transition-all shadow-lg shadow-emerald-100 flex items-center justify-center gap-2"
                        >
                          <UserCheck className="w-5 h-5" />
                          Verify & Proceed
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {verificationStep === 'processing' && (
                  <div className="text-center py-10">
                    <div className="relative w-24 h-24 mx-auto mb-8">
                      <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
                      <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <ShieldCheck className="text-indigo-600 w-10 h-10" />
                      </div>
                    </div>
                    <h4 className="text-lg font-bold mb-2">Analyzing Identity...</h4>
                    <p className="text-slate-500 text-sm">Our AI is matching your face with your Voter ID. This will only take a moment.</p>
                    
                    <div className="mt-8 space-y-2">
                      <div className="flex justify-between text-xs font-bold text-slate-400 uppercase">
                        <span>Face Match</span>
                        <span className="text-emerald-500">98.4%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: '98.4%' }}
                          className="bg-emerald-500 h-full"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setCurrentView('voting')}>
              <div className="bg-indigo-600 p-2 rounded-lg">
                <ShieldCheck className="text-white w-6 h-6" />
              </div>
              <h1 className="text-xl font-bold tracking-tight text-slate-800">SecureVote</h1>
            </div>

            {account && (
              <nav className="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                <button
                  onClick={() => setCurrentView('voting')}
                  className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${
                    currentView === 'voting' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Vote
                </button>
                <button
                  onClick={() => setCurrentView('results')}
                  className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${
                    currentView === 'results' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Results
                </button>
              </nav>
            )}
          </div>
          
          <div className="flex items-center gap-4">
            {isOwner && (
              <button
                onClick={() => setIsElectionConcluded(!isElectionConcluded)}
                className={`hidden sm:flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all border ${
                  isElectionConcluded 
                    ? 'bg-rose-50 text-rose-600 border-rose-200' 
                    : 'bg-emerald-50 text-emerald-600 border-emerald-200'
                }`}
              >
                {isElectionConcluded ? "Re-open Election" : "End Election"}
              </button>
            )}
            <button
              onClick={connectWallet}
              disabled={loading}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-full font-medium transition-all disabled:opacity-50"
            >
              {account ? (
                <>
                  <Wallet className="w-4 h-4" />
                  {account.slice(0, 6)}...{account.slice(-4)}
                </>
              ) : (
                "Connect Wallet"
              )}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Iframe Warning */}
        {isInIframe && (
          <div className="mb-8 p-4 bg-indigo-900 text-white rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg border border-indigo-400/30">
            <div className="flex items-center gap-3">
              <div className="bg-indigo-500/30 p-2 rounded-lg">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <p className="font-bold text-sm">Secure Environment Required</p>
                <p className="text-indigo-200 text-xs">Biometrics are often blocked in preview windows for security. Open in a new tab for full functionality.</p>
              </div>
            </div>
            <button 
              onClick={openInNewTab}
              className="whitespace-nowrap bg-white text-indigo-900 px-4 py-2 rounded-lg font-bold text-xs hover:bg-indigo-50 transition-colors"
            >
              Launch in Secure Tab
            </button>
          </div>
        )}

        {/* Countdown Timer Banner */}
        {timeLeft && !isElectionConcluded && (
          <div className="mb-8 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="bg-rose-100 p-3 rounded-2xl">
                <Loader2 className="w-8 h-8 text-rose-600 animate-spin" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800">Election Countdown</h3>
                <p className="text-slate-500 text-sm">Voting will automatically conclude when the timer reaches zero.</p>
              </div>
            </div>
            
            <div className="flex gap-4">
              {[
                { label: 'Hours', value: timeLeft.hours },
                { label: 'Minutes', value: timeLeft.minutes },
                { label: 'Seconds', value: timeLeft.seconds }
              ].map((unit) => (
                <div key={unit.label} className="flex flex-col items-center">
                  <div className="bg-slate-900 text-white w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black shadow-lg">
                    {unit.value.toString().padStart(2, '0')}
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase mt-2 tracking-widest">{unit.label}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Status Banner */}
        <AnimatePresence>
          {status && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`mb-8 p-4 rounded-xl flex items-center gap-3 ${
                status.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                status.type === 'error' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                'bg-indigo-50 text-indigo-700 border border-indigo-200'
              }`}
            >
              {status.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> :
               status.type === 'error' ? <AlertCircle className="w-5 h-5" /> :
               <Loader2 className="w-5 h-5 animate-spin" />}
              <p className="font-medium">
                {status.message}
                {status.message.includes("new tab") && (
                  <button 
                    onClick={() => window.open(window.location.href, '_blank')}
                    className="ml-2 underline font-bold"
                  >
                    Open Now
                  </button>
                )}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {!account ? (
          <div className="text-center py-20">
            <div className="bg-indigo-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <VoteIcon className="text-indigo-600 w-10 h-10" />
            </div>
            <h2 className="text-3xl font-bold mb-4">Welcome to SecureVote</h2>
            <p className="text-slate-600 max-w-md mx-auto mb-8">
              A decentralized, biometric-secured voting platform. Connect your wallet to participate in active elections.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={connectWallet}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-full font-bold text-lg shadow-lg shadow-indigo-200 transition-all"
              >
                Connect Wallet
              </button>
              <button
                onClick={startDemoMode}
                className="bg-white border-2 border-indigo-600 text-indigo-600 hover:bg-indigo-50 px-8 py-3 rounded-full font-bold text-lg transition-all"
              >
                Try Demo Mode
              </button>
            </div>
            <p className="mt-6 text-slate-400 text-sm">
              Don't have MetaMask? <a href="https://metamask.io/download/" target="_blank" rel="noopener noreferrer" className="text-indigo-500 underline">Download it here</a>.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Voter Profile */}
            <div className="lg:col-span-1">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <User className="w-5 h-5 text-indigo-600" />
                  Voter Profile
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-500 text-sm">Authorization</span>
                    {isAuthorized ? (
                      <span className="text-emerald-600 font-bold text-sm flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Authorized
                      </span>
                    ) : (
                      <span className="text-rose-600 font-bold text-sm flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" /> Not Authorized
                      </span>
                    )}
                  </div>
                  <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-500 text-sm">Voting Status</span>
                    {hasVoted ? (
                      <span className="text-indigo-600 font-bold text-sm">Vote Cast</span>
                    ) : (
                      <span className="text-slate-400 font-bold text-sm">Pending</span>
                    )}
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-slate-100">
                  <h4 className="text-sm font-bold mb-3 flex items-center gap-2">
                    <Fingerprint className="w-4 h-4 text-indigo-600" />
                    Biometric Settings
                  </h4>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">Use Simulated Mode</span>
                    <button 
                      onClick={() => setUseSimulatedBiometrics(!useSimulatedBiometrics)}
                      className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${useSimulatedBiometrics ? 'bg-indigo-600' : 'bg-slate-300'}`}
                    >
                      <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${useSimulatedBiometrics ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                  </div>
                  <p className="mt-2 text-[10px] text-slate-400 leading-tight">
                    {useSimulatedBiometrics 
                      ? "Simulation active to prevent browser errors in the preview window." 
                      : "Real biometrics active. Ensure you are in a secure tab."}
                  </p>
                </div>

                {!isAuthorized && (
                  <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-xl">
                    <p className="text-amber-800 text-xs leading-relaxed mb-3">
                      <strong>Note:</strong> You must be authorized by the admin to vote. 
                      Click below to self-authorize for this demo.
                    </p>
                    <button
                      onClick={handleAuthorize}
                      disabled={loading}
                      className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-all disabled:opacity-50"
                    >
                      {loading ? "Authorizing..." : "Authorize My Account"}
                    </button>
                  </div>
                )}

                {isOwner && (
                  <div className="mt-6 p-4 bg-indigo-50 border border-indigo-200 rounded-xl">
                    <h4 className="text-indigo-800 text-sm font-bold mb-2 flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4" /> Admin Controls
                    </h4>
                    <p className="text-indigo-700 text-xs mb-3">
                      You are the contract owner. You can manage candidates and authorize voters.
                    </p>
                    
                    {!showAddCandidateForm ? (
                      <div className="space-y-2">
                        <button
                          onClick={() => setShowAddCandidateForm(true)}
                          className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all"
                        >
                          Add New Candidate
                        </button>
                        
                        <div className="pt-4 border-t border-indigo-100">
                          <label className="block text-[10px] font-bold text-indigo-900 uppercase mb-2">Set Election Duration (Hours)</label>
                          <div className="flex gap-2">
                            <input 
                              type="number" 
                              value={electionDuration}
                              onChange={(e) => setElectionDuration(e.target.value)}
                              className="flex-1 px-3 py-2 bg-white border border-indigo-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              min="1"
                            />
                            <button
                              onClick={handleSetDuration}
                              className="px-4 py-2 bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold hover:bg-indigo-200 transition-all"
                            >
                              Set
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <form onSubmit={handleAddCandidate} className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-bold text-indigo-900 uppercase mb-1">Candidate Name</label>
                          <input 
                            type="text" 
                            value={newCandidateName}
                            onChange={(e) => setNewCandidateName(e.target.value)}
                            placeholder="e.g. John Doe"
                            className="w-full px-3 py-2 bg-white border border-indigo-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-indigo-900 uppercase mb-1">Party Name</label>
                          <input 
                            type="text" 
                            value={newCandidateParty}
                            onChange={(e) => setNewCandidateParty(e.target.value)}
                            placeholder="e.g. Liberty Party"
                            className="w-full px-3 py-2 bg-white border border-indigo-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            required
                          />
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="submit"
                            disabled={loading}
                            className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all disabled:opacity-50"
                          >
                            {loading ? "Adding..." : "Confirm"}
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowAddCandidateForm(false)}
                            className="px-3 py-2 bg-white border border-indigo-200 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-50 transition-all"
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Candidates Dashboard */}
            <div className="lg:col-span-2">
              {currentView === 'voting' ? (
                <>
                  <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                    <VoteIcon className="w-6 h-6 text-indigo-600" />
                    {isElectionConcluded ? "Election Concluded" : "Active Candidates"}
                  </h3>
                  
                  {isElectionConcluded && (
                    <div className="mb-8 p-6 bg-indigo-50 border border-indigo-200 rounded-2xl text-center">
                      <ShieldCheck className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
                      <h4 className="text-xl font-bold text-indigo-900 mb-2">Voting is now closed</h4>
                      <p className="text-indigo-700 mb-4">The final results are being verified on the Polygon blockchain.</p>
                      <button 
                        onClick={() => setCurrentView('results')}
                        className="bg-indigo-600 text-white px-6 py-2 rounded-full font-bold hover:bg-indigo-700 transition-all"
                      >
                        View Final Results
                      </button>
                    </div>
                  )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {candidates.map((candidate) => (
                      <motion.div
                        key={candidate.id}
                        whileHover={!isElectionConcluded ? { y: -4 } : {}}
                        className={`bg-white p-6 rounded-2xl border border-slate-200 shadow-sm transition-all ${!isElectionConcluded ? 'hover:shadow-md' : 'opacity-80'}`}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="text-lg font-bold text-slate-800">{candidate.name}</h4>
                              {candidate.isVerified ? (
                                <div className="bg-emerald-100 text-emerald-700 p-0.5 rounded-full" title="Identity Verified">
                                  <ShieldCheck className="w-4 h-4" />
                                </div>
                              ) : (
                                <div className="bg-amber-100 text-amber-700 p-0.5 rounded-full" title="Pending Verification">
                                  <AlertCircle className="w-4 h-4" />
                                </div>
                              )}
                              
                              {isOwner && !candidate.isVerified && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleVerifyCandidate(candidate.id);
                                  }}
                                  disabled={loading}
                                  className="ml-auto sm:ml-0 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 shadow-sm disabled:opacity-50"
                                >
                                  <ShieldCheck className="w-3 h-3" />
                                  Verify Identity
                                </button>
                              )}
                            </div>
                            <p className="text-indigo-600 text-sm font-medium">{candidate.party}</p>
                          </div>
                          <div className="bg-slate-100 px-3 py-1 rounded-full text-xs font-bold text-slate-500 ml-2">
                            ID: {candidate.id}
                          </div>
                        </div>
                        
                        <div className="mb-6">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-slate-500">Current Votes</span>
                            <span className="font-bold">{candidate.voteCount}</span>
                          </div>
                          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                            <div 
                              className="bg-indigo-500 h-full transition-all duration-1000" 
                              style={{ 
                                width: `${totalVotesCast > 0 ? (candidate.voteCount / totalVotesCast) * 100 : 0}%` 
                              }}
                            />
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1 text-right">
                            {totalVotesCast > 0 ? ((candidate.voteCount / totalVotesCast) * 100).toFixed(1) : 0}% of total
                          </p>
                        </div>

                        <div className="flex flex-col gap-2">
                          <button
                            onClick={() => handleVote(candidate.id)}
                            disabled={!isAuthorized || hasVoted || loading || isAuthenticating || isElectionConcluded || !candidate.isVerified}
                            className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                              hasVoted || isElectionConcluded || !candidate.isVerified
                                ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-100 disabled:opacity-50'
                            }`}
                          >
                            {isAuthenticating ? (
                              <>
                                <Fingerprint className="w-5 h-5 animate-pulse" />
                                Verifying Biometrics...
                              </>
                            ) : hasVoted ? (
                              <>
                                <CheckCircle2 className="w-5 h-5" />
                                Vote Recorded
                              </>
                            ) : isElectionConcluded ? (
                              <>
                                <ShieldCheck className="w-5 h-5" />
                                Election Closed
                              </>
                            ) : !candidate.isVerified ? (
                              <>
                                <AlertCircle className="w-5 h-5" />
                                Awaiting Verification
                              </>
                            ) : (
                              <>
                                <Fingerprint className="w-5 h-5" />
                                Vote with Biometrics
                              </>
                            )}
                          </button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </>
              ) : (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm"
                >
                  <div className="text-center mb-10">
                    <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 relative">
                      <CheckCircle2 className="text-indigo-600 w-8 h-8" />
                      {!isDemoMode && (
                        <span className="absolute -top-1 -right-1 flex h-4 w-4">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500"></span>
                        </span>
                      )}
                    </div>
                    <h3 className="text-2xl font-bold text-slate-800">Election Results</h3>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <p className="text-slate-500 text-sm">Real-time vote distribution</p>
                      {!isDemoMode && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full uppercase tracking-wider">
                          <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                          Live
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 mt-2 italic">
                      Last updated: {lastUpdated.toLocaleTimeString()}
                    </p>
                  </div>

                  <div className="space-y-8">
                    {candidates
                      .sort((a, b) => b.voteCount - a.voteCount)
                      .map((candidate, index) => (
                        <div key={candidate.id} className="relative">
                          <div className="flex justify-between items-end mb-2">
                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                {index === 0 && totalVotesCast > 0 && (
                                  <span className="bg-amber-100 text-amber-700 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">Leader</span>
                                )}
                                <h4 className="font-bold text-slate-800">{candidate.name}</h4>
                                {candidate.isVerified ? (
                                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                                ) : (
                                  <div className="flex items-center gap-2">
                                    <AlertCircle className="w-4 h-4 text-amber-600" />
                                    {isOwner && (
                                      <button
                                        onClick={() => handleVerifyCandidate(candidate.id)}
                                        disabled={loading}
                                        className="bg-emerald-600 hover:bg-emerald-700 text-white px-2 py-0.5 rounded text-[10px] font-bold transition-all disabled:opacity-50"
                                      >
                                        Verify
                                      </button>
                                    )}
                                  </div>
                                )}
                              </div>
                              <p className="text-xs text-slate-400">{candidate.party}</p>
                            </div>
                            <div className="text-right">
                              <span className="text-2xl font-black text-indigo-600">{candidate.voteCount}</span>
                              <span className="text-slate-400 text-xs ml-1">votes</span>
                            </div>
                          </div>
                          <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${totalVotesCast > 0 ? (candidate.voteCount / totalVotesCast) * 100 : 0}%` }}
                              transition={{ duration: 1, delay: index * 0.1 }}
                              className={`h-full ${index === 0 ? 'bg-indigo-600' : 'bg-indigo-400'}`}
                            />
                          </div>
                          <div className="flex justify-between mt-1">
                            <span className="text-[10px] font-bold text-slate-400">Rank #{index + 1}</span>
                            <span className="text-[10px] font-bold text-indigo-500">
                              {totalVotesCast > 0 ? ((candidate.voteCount / totalVotesCast) * 100).toFixed(1) : 0}%
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>

                  <div className="mt-12 p-6 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-center">
                    <p className="text-slate-500 text-sm mb-2">Total Verified Votes</p>
                    <p className="text-4xl font-black text-slate-800">{totalVotesCast}</p>
                    <div className="mt-4 flex items-center justify-center gap-2 text-emerald-600 text-xs font-bold">
                      <ShieldCheck className="w-4 h-4" />
                      Secured by Polygon Blockchain
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-20 py-10 border-t border-slate-200 text-center text-slate-400 text-sm">
        <p>© 2026 SecureVote • Powered by Polygon & WebAuthn</p>
      </footer>
    </div>
  );
}
