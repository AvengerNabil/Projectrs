import { useState, useCallback } from 'react';

/**
 * useBiometricAuth Hook
 * 
 * This hook leverages the WebAuthn API to provide biometric authentication.
 * In a production environment, the 'challenge' and 'credentialId' would be 
 * verified against a server or a smart contract (e.g., ERC-4337 Account Abstraction).
 * For this demo, it acts as a secure "gate" that must be passed before the 
 * blockchain transaction is initiated.
 */
export const useBiometricAuth = () => {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const authenticate = useCallback(async (voterAddress: string, simulate: boolean = false) => {
    setIsAuthenticating(true);
    setError(null);

    if (simulate) {
      // Simulate biometric delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      setIsAuthenticating(false);
      return true;
    }

    try {
      if (!window.PublicKeyCredential) {
        throw new Error("Biometric authentication is not supported on this browser.");
      }

      const challenge = new Uint8Array(32);
      window.crypto.getRandomValues(challenge);
      
      const publicKeyCredentialCreationOptions: PublicKeyCredentialCreationOptions = {
        challenge,
        rp: { name: "Decentralized Voting System" },
        user: {
          id: Uint8Array.from(voterAddress, c => c.charCodeAt(0)),
          name: voterAddress,
          displayName: `Voter ${voterAddress.slice(0, 6)}`,
        },
        pubKeyCredParams: [{ alg: -7, type: "public-key" }],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "required",
        },
        timeout: 60000,
        attestation: "none",
      };

      const credential = await navigator.credentials.create({
        publicKey: publicKeyCredentialCreationOptions,
      });

      return !!credential;
    } catch (err: any) {
      console.error("Biometric Error Details:", {
        name: err.name,
        message: err.message,
        code: err.code
      });

      let message = "Biometric authentication failed.";

      // Specific WebAuthn Error Handling
      switch (err.name) {
        case "NotAllowedError":
          if (err.message.includes("Permissions Policy") || err.message.includes("publickey-credentials")) {
            message = "Biometric access is blocked in this preview window. Please use 'Simulated Mode' or click 'Launch in Secure Tab' at the top.";
          } else {
            message = "Authentication cancelled or permission denied by user.";
          }
          break;
        case "SecurityError":
          message = "Security policy violation. This usually happens when the domain is not secure (HTTPS) or blocked by an iframe policy.";
          break;
        case "NotSupportedError":
          message = "Biometric hardware not found or not supported on this device/browser.";
          break;
        case "InvalidStateError":
          message = "This device is already registered or in an invalid state for this request.";
          break;
        case "TimeoutError":
          message = "Authentication timed out. Please try again.";
          break;
        case "AbortError":
          message = "Authentication process was aborted.";
          break;
        default:
          message = err.message || "An unexpected biometric error occurred.";
      }
      
      setError(message);
      return false;
    } finally {
      setIsAuthenticating(false);
    }
  }, []);

  return { authenticate, isAuthenticating, error };
};
