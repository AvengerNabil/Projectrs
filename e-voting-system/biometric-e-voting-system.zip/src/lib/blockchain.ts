import { ethers } from 'ethers';

// ABI for the SecureVote contract
export const CONTRACT_ABI = [
  "function candidates(uint256) view returns (uint256 id, string name, string party, uint256 voteCount, bool isVerified)",
  "function candidatesCount() view returns (uint256)",
  "function hasVoted(address) view returns (bool)",
  "function isAuthorized(address) view returns (bool)",
  "function castVote(uint256 _candidateId) public",
  "function authorizeVoter(address _voter) public",
  "function addCandidate(string _name, string _party) public",
  "function verifyCandidate(uint256 _candidateId) public",
  "function owner() view returns (address)",
  "event VoteCast(address indexed voter, uint256 indexed candidateId)"
];

// Replace with your deployed contract address on Polygon Amoy
export const CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000"; 

export const getContract = async (signerOrProvider: ethers.Signer | ethers.Provider) => {
  return new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signerOrProvider);
};
